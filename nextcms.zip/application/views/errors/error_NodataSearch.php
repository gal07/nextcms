<h2 style="text-align:center;">No Data "<?php echo $this->input->post('kunci');?>"</h2>
<a href="<?php echo base_url().$link;?>" class="blue-text"><p style="text-align:center;">Back</p></a>
