
    <!-- Jquery Core Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Jquery Validation Plugin Css -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-validation/jquery.validate.js"></script>

    <!-- JQuery Steps Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-steps/jquery.steps.js"></script>

    <!-- Bootstrap Notify Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/bootstrap-notify/bootstrap-notify.js"></script>

    <!-- Sweet Alert Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/sweetalert/sweetalert.min.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/node-waves/waves.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/admin.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/pages/forms/form-validation.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/pages/tables/jquery-datatable.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/pages/ui/notifications.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/extends-ajax.js"></script>

    <!-- Demo Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/demo.js"></script>
</body>

</html>