    <!-- Jquery Core Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/node-waves/waves.js"></script>

    <!-- Validation Plugin Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>plugins/jquery-validation/jquery.validate.js"></script>

    <!-- Custom Js -->
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/admin.js"></script>
    <script src="<?php echo base_url().'assets/resource/admin/';?>js/pages/examples/sign-in.js"></script>
</body>

</html>