<h2 style="text-align:center;">No Data Available</h2>

<a href="<?php echo base_url().'user/UploadBankGambar'?>" class="btn btn-warning"><strong>+</strong> New Picture</a>
