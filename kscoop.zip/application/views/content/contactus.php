<br><br><br><br><div class="container">
  <h2 class="display-5 text-center">Hubungi Kami</h2>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><i class="fab fa-instagram fa-2x" style="color:rgb(150, 111, 189);"></i>    @perangsanglele</li>
    <li class="list-group-item"><i class="fab fa-whatsapp fa-2x" style="color:rgb(51, 210, 38)"></i>    02588564456</li>
    <li class="list-group-item"><i class="fab fa-google-plus fa-2x" style="color:rgb(215, 23, 11)"></i>   galihkur29@gmail.com</li>
  </ul>
</div>
<br><br><br><br><br>
