<br>
<div class="container">
  <div class="display-4 text-center">
    Tentang Kami
  </div>
  <img src="<?php echo base_url().'assets/picture_web/ads.jpg';?>" alt="Tentang Kami" class="img-fluid">
</div>
