<?php

echo $error;
